#include "batterydesign.h"

batterydesign::batterydesign(QWidget *parent) : QWidget(parent)
{
}

