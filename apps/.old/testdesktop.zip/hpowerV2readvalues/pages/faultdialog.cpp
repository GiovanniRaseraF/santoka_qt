#include "faultdialog.h"
#include <iostream>

faultdialog::faultdialog(QWidget *parent) : QDialog(parent)
{
   setupUi(this);

   // Setup informations
}

faultdialog::~faultdialog(){}
