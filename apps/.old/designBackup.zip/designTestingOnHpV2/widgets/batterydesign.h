#ifndef BATTERYDESIGN_H
#define BATTERYDESIGN_H

#include <QWidget>
#include <QObject>

class batterydesign : public QWidget
{
public:
    explicit batterydesign(QWidget *parent = nullptr);
};

#endif // BATTERYDESIGN_H
